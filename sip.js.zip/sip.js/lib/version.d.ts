export declare const LIBRARY_VERSION = "0.21.1";
