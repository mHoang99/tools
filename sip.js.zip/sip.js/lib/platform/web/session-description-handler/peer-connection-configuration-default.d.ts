/**
 * Function which returns an RTCConfiguration.
 * @public
 */
export declare function defaultPeerConnectionConfiguration(): RTCConfiguration;
