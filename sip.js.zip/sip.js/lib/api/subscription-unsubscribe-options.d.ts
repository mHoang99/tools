/**
 * Options for {@link Subscription.unsubscribe}.
 * @public
 */
export interface SubscriptionUnsubscribeOptions {
}
