/**
 * Options for {@link Subscriber.subscribe}.
 * @public
 */
export interface SubscriberSubscribeOptions {
}
