/**
 * Log levels.
 * @public
 */
export declare enum Levels {
    error = 0,
    warn = 1,
    log = 2,
    debug = 3
}
