/**
 * FIXME: TODO: Should be configurable/variable.
 */
export declare const AllowedMethods: string[];
